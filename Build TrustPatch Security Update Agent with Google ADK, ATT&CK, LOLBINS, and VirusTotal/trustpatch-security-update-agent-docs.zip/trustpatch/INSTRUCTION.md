# TrustPatch Operational Instructions

## Purpose

These instructions define how operators use TrustPatch safely.

## Modes

### Observe

```bash
trustpatch scan ./project
```

No changes.

### Plan

```bash
trustpatch plan ./project
```

Creates candidate updates without modifying the target.

### Prepare

```bash
trustpatch run ./project --mode prepare-only
```

Creates isolated candidate workspaces and verification evidence.

### Verify

```bash
trustpatch verify ./project
```

Runs verification against a prepared candidate.

### Approve

```bash
trustpatch approve UPDATE-ID
```

Approvals must be explicit and auditable.

### Reject

```bash
trustpatch reject UPDATE-ID
```

Rejected changes must not be applied.

## Recommended Operator Workflow

1. Start with `scan`.
2. Review dependency and vulnerability evidence.
3. Run `plan`.
4. Inspect the proposed change.
5. Allow preparation in a sandbox.
6. Review tests and independent verification.
7. Approve only the exact candidate represented by the evidence.
8. Apply.
9. Review final verification.
10. Retain the audit report.

## Approval Checklist

Before approval verify:

- Correct project.
- Correct dependency.
- Current version.
- Proposed version.
- Advisory evidence.
- Expected files.
- Actual diff.
- Tests passed.
- Build passed where applicable.
- Vulnerability rescan completed.
- Independent verification passed.
- No unexpected changes.
- Rollback information exists.

## Emergency Security Updates

Emergency workflows should not bypass the audit trail.

If organizational policy allows emergency changes, use an explicit emergency policy that still records:

- who authorized it
- why it was urgent
- what changed
- evidence available at the time
- what post-change verification was performed

## Credentials

Never provide production credentials to TrustPatch.

Use short-lived, least-privilege credentials only where required by an approved integration.

## Network

Default sandbox network access is disabled.

If a package manager requires network access, use an allowlist and record:

- destination
- reason
- duration
- policy that authorized it

## Artifacts

Preserve:

- scan report
- update plan
- patch
- test output
- SBOM
- vulnerability report
- verification report
- approval record
- final audit record

## Incident Handling

If TrustPatch behaves unexpectedly:

1. Stop the operation.
2. Preserve logs.
3. Destroy only temporary execution environments after evidence capture.
4. Do not apply pending changes.
5. Review unexpected file/network/process activity.
6. Escalate according to the organization's incident process.
