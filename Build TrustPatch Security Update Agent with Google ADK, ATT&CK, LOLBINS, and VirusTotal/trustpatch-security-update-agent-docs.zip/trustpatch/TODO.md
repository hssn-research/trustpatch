# TrustPatch TODO

## Phase 0 — Repository Foundation

- [ ] Create Python package using `pyproject.toml`.
- [ ] Add CLI framework.
- [ ] Add typed configuration.
- [ ] Add structured logging.
- [ ] Add JSON schemas.
- [ ] Add test framework.
- [ ] Add CI pipeline.
- [ ] Add pre-commit/static quality checks.

## Phase 1 — Project Discovery

- [ ] Implement Git detection.
- [ ] Implement project root discovery.
- [ ] Detect Python.
- [ ] Detect Node.js.
- [ ] Detect Go.
- [ ] Detect Rust.
- [ ] Detect Java.
- [ ] Detect .NET.
- [ ] Detect package manifests.
- [ ] Detect lockfiles.
- [ ] Detect test commands.
- [ ] Detect build commands.

## Phase 2 — Dependency Inventory

- [ ] Python inventory adapter.
- [ ] Node inventory adapter.
- [ ] Go inventory adapter.
- [ ] Rust inventory adapter.
- [ ] Normalize dependency records.
- [ ] Build dependency graph.
- [ ] Identify direct/transitive dependencies.
- [ ] Identify runtime/development scope.
- [ ] Record lockfile provenance.

## Phase 3 — Security Intelligence

- [ ] Integrate OSV.
- [ ] Normalize advisory records.
- [ ] Match affected ranges.
- [ ] Identify fixed versions.
- [ ] Record advisory evidence.
- [ ] Add vulnerability cache.
- [ ] Add retry/backoff.
- [ ] Add offline evidence mode.

## Phase 4 — SBOM

- [ ] Generate CycloneDX SBOM.
- [ ] Store pre-update SBOM.
- [ ] Store post-update SBOM.
- [ ] Compare SBOMs.
- [ ] Verify expected dependency delta.

## Phase 5 — Risk Engine

- [ ] Implement severity model.
- [ ] Implement update magnitude detection.
- [ ] Detect runtime dependencies.
- [ ] Detect authentication dependencies.
- [ ] Detect cryptographic dependencies.
- [ ] Detect database dependencies.
- [ ] Detect native dependencies.
- [ ] Calculate blast radius.
- [ ] Produce explainable risk reasons.

## Phase 6 — Policy Engine

- [ ] YAML policy parser.
- [ ] Default fail-closed policy.
- [ ] Approval requirements.
- [ ] Auto-apply allowlist.
- [ ] Deny rules.
- [ ] Policy validation.
- [ ] Policy integrity protection.

## Phase 7 — Update Planner

- [ ] Generate candidate updates.
- [ ] Determine minimal fixed version.
- [ ] Detect major/minor/patch changes.
- [ ] Generate expected-change manifest.
- [ ] Generate update plan.
- [ ] Support dry-run.

## Phase 8 — Sandbox

- [ ] Git worktree isolation.
- [ ] Container execution.
- [ ] Network isolation.
- [ ] Resource limits.
- [ ] Timeouts.
- [ ] Temporary credentials.
- [ ] Artifact collection.
- [ ] Workspace cleanup.

## Phase 9 — Testing

- [ ] Unit-test execution.
- [ ] Integration-test execution.
- [ ] Build execution.
- [ ] Package resolution validation.
- [ ] SAST integration.
- [ ] Secret scanning.
- [ ] Dependency vulnerability rescan.

## Phase 10 — Independent Verification

- [ ] Separate verifier implementation.
- [ ] Verify resolved versions.
- [ ] Verify lockfiles.
- [ ] Verify expected files.
- [ ] Detect unexpected files.
- [ ] Compare dependency graphs.
- [ ] Rebuild.
- [ ] Rerun required tests.
- [ ] Verify vulnerability removal.
- [ ] Verify SBOM delta.

## Phase 11 — Approval

- [ ] Approval objects.
- [ ] CLI approval flow.
- [ ] Approval expiration.
- [ ] Evidence digest binding.
- [ ] Approval identity.
- [ ] Rejection reason.
- [ ] Audit approval events.

## Phase 12 — Application

- [ ] Apply approved patch.
- [ ] Verify target commit.
- [ ] Final dependency scan.
- [ ] Final security scan.
- [ ] Final test.
- [ ] Rollback command.

## Phase 13 — Audit

- [ ] Structured audit events.
- [ ] Event IDs.
- [ ] Evidence hashes.
- [ ] Append-only storage.
- [ ] Optional signatures.
- [ ] Human-readable reports.
- [ ] JSON export.

## Phase 14 — Integrations

- [ ] GitHub pull requests.
- [ ] GitLab merge requests.
- [ ] CI integration.
- [ ] Scheduled scanning.
- [ ] Slack/email notifications.
- [ ] Web dashboard.

## Phase 15 — Hardening

- [ ] Threat model review.
- [ ] Sandbox escape testing.
- [ ] Dependency confusion testing.
- [ ] Malicious package fixtures.
- [ ] Prompt injection fixtures.
- [ ] Policy bypass tests.
- [ ] Audit tamper tests.
- [ ] Reproducibility tests.
