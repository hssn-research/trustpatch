# TrustPatch Definition of Done

This file defines what must be complete before calling a TrustPatch release production-ready.

## 1. Foundation

- [ ] Repository builds cleanly.
- [ ] CLI starts correctly.
- [ ] Configuration validation works.
- [ ] Test suite executes in CI.
- [ ] Static type checking passes.
- [ ] Linting passes.
- [ ] Security dependency scan passes.

## 2. Discovery

- [ ] Python projects detected.
- [ ] Node.js projects detected.
- [ ] Go projects detected.
- [ ] Rust projects detected.
- [ ] Manifests detected.
- [ ] Lockfiles detected.
- [ ] Git repositories handled safely.

## 3. Vulnerability Detection

- [ ] Vulnerability database integration works.
- [ ] Affected version matching is tested.
- [ ] Fixed version detection is tested.
- [ ] Advisory evidence is retained.
- [ ] Offline/error conditions fail safely.

## 4. Update Planning

- [ ] Candidate version selection is deterministic.
- [ ] Major/minor/patch classification works.
- [ ] Expected-change manifest is generated.
- [ ] Risk classification is explainable.
- [ ] Policy decision is deterministic.

## 5. Sandbox

- [ ] Candidate changes never touch the primary workspace.
- [ ] Network restrictions work.
- [ ] Resource limits work.
- [ ] Timeouts work.
- [ ] Host credentials are unavailable.
- [ ] Temporary artifacts are cleaned safely.

## 6. Testing

- [ ] Tests run in isolated environments.
- [ ] Build verification works.
- [ ] Security scanning works.
- [ ] Test evidence is retained.
- [ ] Failures block application.

## 7. Independent Verification

- [ ] Verifier does not trust updater output.
- [ ] Resolved versions are independently checked.
- [ ] Git diff is independently checked.
- [ ] Unexpected files block application.
- [ ] SBOM delta is checked.
- [ ] Vulnerability rescan is checked.
- [ ] Final verification is reproducible.

## 8. Approval

- [ ] High-risk changes require approval.
- [ ] Approval is bound to exact evidence.
- [ ] Rejection prevents application.
- [ ] Expired approvals cannot be reused.
- [ ] Approval events are audited.

## 9. Application

- [ ] Only authorized changes can be applied.
- [ ] Final commit/diff is verified.
- [ ] Final dependency state is scanned.
- [ ] Final security state is verified.
- [ ] Rollback is tested.

## 10. Audit

- [ ] Every security-sensitive operation has an event ID.
- [ ] Audit records include timestamps.
- [ ] Audit records include agent version.
- [ ] Evidence hashes are recorded.
- [ ] Approval identity is recorded.
- [ ] Audit export works.
- [ ] Tamper-evidence is implemented for production.

## 11. LLM Safety

- [ ] LLM cannot directly authorize changes.
- [ ] LLM cannot retrieve production credentials.
- [ ] LLM cannot bypass policy.
- [ ] LLM-generated explanations are marked as explanations.
- [ ] Deterministic security evidence remains authoritative.
- [ ] Prompt injection tests exist.

## 12. Release Gate

A release is not production-ready until all critical requirements are complete and all high-severity security tests pass.

The release checklist must be signed by the designated engineering/security owner.
